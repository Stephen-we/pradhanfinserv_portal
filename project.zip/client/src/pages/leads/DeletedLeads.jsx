// client/src/pages/leads/DeletedLeads.jsx
import React from "react";

export default function DeletedLeads() {
  return (
    <div>
      <h1>Deleted Leads</h1>
      <p>This will show deleted leads.</p>
    </div>
  );
}